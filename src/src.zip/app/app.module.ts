import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {UIRouterModule} from "@uirouter/angular";
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HomeComponent } from './core/home.component';
import { AboutComponent } from './core/about.component';
import { OrderProductComponent } from './features/order-product/order-product.component';

let homeState = { name: 'home', url: '/',  component: HomeComponent }; 
let aboutState = { name: 'about', url: '/about',  component: AboutComponent };
let orderProductState = { name: 'orderproduct', url: '/order-product', component: OrderProductComponent };

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutComponent,
    OrderProductComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    UIRouterModule.forRoot({ states: [ homeState, aboutState, orderProductState ], useHash: true }),
    // import HttpClientModule after BrowserModule.
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
