export class Beverage {
    id: number;
    name: string;
    category: number;
    price: number;
}