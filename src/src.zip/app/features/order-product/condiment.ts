export class Condiment {
    id: number;
    name: string;
    price: number;
}