export class BeverageCategory {
    id: number;
    name: string;
    imagepath: string;
}