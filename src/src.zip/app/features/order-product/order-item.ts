export class OrderItem {
    id: number;
    additionaldesc: string;
    quantity: number;
    unitprice: number;
}