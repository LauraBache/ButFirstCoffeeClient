import {Component, OnInit } from '@angular/core';

import { Beverage } from "./beverage";
import { BeverageCategory } from './beverage-category';
import { Condiment } from './condiment'
import { Order } from "./order";
import { OrderItem } from './order-item';

@Component({
  selector: 'app-order-product',
  templateUrl: 'order-product.component.html',
  styleUrls: ['order-product.component.css']
})
export class OrderProductComponent implements OnInit {

    beverageTypeCoffee: BeverageCategory = {
      id: 1,
      name: 'Coffee',
      imagepath: ''
    };

    beverageTypeTea: BeverageCategory = {
      id: 2,
      name: 'Tea',
      imagepath: ''
    };

    coffees: Beverage[] = [
      { id: 1, name: 'House Blend', category: 1, price: 42 },
      { id: 2, name: 'Dark Roast', category: 1, price: 40 },
      { id: 3, name: 'Decaf', category: 1, price: 38 }
    ];

    teas: Beverage[] = [
      { id: 4, name: 'Chai', category: 1, price: 35 },
      { id: 5, name: 'Earl Gery', category: 1, price: 20 },
    ];

    condiments: Condiment[] = [
      { id: 6, name: 'Milk', price: 5 },
      { id: 7, name: 'Syrup', price: 5 },
      { id: 7, name: 'Sugar', price: 5 },
      { id: 7, name: 'Caramel', price: 5 },
      { id: 7, name: 'Cinamon', price: 5 },
      { id: 7, name: 'Chili', price: 5 },
    ];

    order: Order = {
      id: 1,
      orderdate: new Date(2018, 2, 11),
      orderitems: [ 
        { id: 1, additionaldesc: 'House Blend with Milk, Vanilla Syrup' , quantity: 1, unitprice: 42.00 },
        { id: 2, additionaldesc: 'House Blend with Milk'                , quantity: 1, unitprice: 42.00 }],
      totalprice: 25.00,
      complete: true
    };

    beverages: Beverage[] = [];
  
    constructor() { }
  
    ngOnInit() {
      this.beverages = this.teas;
      // add the code to get coffees and teas and condiments
    }

    onBeverageTypeSelect(beverageType: BeverageCategory): void {

      if (beverageType.name == 'Coffee')
      {
        this.beverages = this.coffees;
      }
      else
      {
        this.beverages = this.teas;
      }
    };

    selectedBeverage: Beverage;

    onBeverageSelect(beverage: Beverage): void {
      this.selectedBeverage = beverage;

      // // find/remove all active classes from each beverage list item
      // $('.list-beverage-item').removeClass('selectedBeverage');

      // // add active to selected item
      // $(this).addClass('selectedBeverage');

      // add to orderitem
    }

    currentOrderItem: OrderItem;
    selectedCondiments: Condiment[] = [];

    onCondimentSelect(condiment: Condiment): void {
      // this is where the decorator comes in and things get tricky,
      // how to handle when a customer unselect a condiment? Check the selected condiments, have a method to remove a decoration
      // or maybe just a way to remove an order item and then disable button when selected
      // or add additional description to the product instead of the order item? the order item will only need the product if everything goes as planned

      // add to orderitem
    }
}