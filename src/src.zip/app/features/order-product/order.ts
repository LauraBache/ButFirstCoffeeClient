import { OrderItem } from "./order-item";

export class Order {
    id: number;
    orderdate: Date;
    orderitems: OrderItem[];
    totalprice: number;
    complete: boolean;
}